@extends('layout')

@section('topbar')
    @include('layout.admin.includes.topbar')
@endsection

@section('content')
    <section>
        <h1>This is Dashboard</h1>
    </section>
    

@endsection