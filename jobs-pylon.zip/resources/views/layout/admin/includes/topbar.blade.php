<ul>
    <li><a href="{{ route('admin.dashboard') }}" class="nav-link scrollto">Dashboard</a></li>
    <li><a href="{{ route('admin.jobposts') }}" class="nav-link scrollto">Applicants</a></li>
    <li><a href="{{ route('admin.jobposts') }}" class="nav-link scrollto">Job Post</a></li>
</ul>