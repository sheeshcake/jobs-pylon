<ul>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link scrollto">Dashboard</a></li>
    <li><a href="<?php echo e(route('admin.jobposts')); ?>" class="nav-link scrollto">Applicants</a></li>
    <li><a href="<?php echo e(route('admin.jobposts')); ?>" class="nav-link scrollto">Job Post</a></li>
</ul><?php /**PATH C:\Users\Pylon\Documents\LaravelWorkspace\jobs-pylon\resources\views/layout/admin/includes/topbar.blade.php ENDPATH**/ ?>