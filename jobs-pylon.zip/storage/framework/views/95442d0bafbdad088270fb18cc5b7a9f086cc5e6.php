

<?php $__env->startSection('topbar'); ?>
    <?php echo $__env->make('layout.admin.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="my-3 d-flex justify-content-center">
            <h3 id="title"><?php echo e($data['posts'][0]['job_title']); ?></h3>
        </div>
        <div class="container">
            <div class="card">
                <img class="card-img-top" src="<?php echo e(url('/')); ?>/img/jobimages/<?php echo e($data['posts'][0]['job_image']); ?>" alt="Card image cap">
                <form action="<?php echo e(route('admin.updatepost')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($data['posts'][0]['id']); ?>">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="title_input">Job Post Title</label>
                            <input type="text" name="job_title" id="title_input" class="form-control" value="<?php echo e($data['posts'][0]['job_title']); ?>">
                        </div>
                        <hr>
                        <div class="form-group">
                            <label for="body_input">Job Post Body</label>
                            <textarea id="body_input" name="job_description" class="form-control"><?php echo e($data['posts'][0]['job_description']); ?></textarea>
                        </div>
                        <hr>
                        <div class="custom-file my-1">
                            <input type="file" class="custom-file-input" name="job_image" id="image_input">
                            <label class="custom-file-label" for="image_input">Choose Image</label>
                        </div>
                        <input type="submit" value="Submit" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>

    </section>
    <script src="https://cdn.ckeditor.com/4.16.0/full/ckeditor.js"></script>
    <script>
            $ckfield = CKEDITOR.replace( 'body_input' );
            $ckfield.on('change', function() {
                $ckfield.updateElement();         
            });
            $("#title_input").on('input', function(){
                $("#title").text($(this).val());
            });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pylon\Documents\LaravelWorkspace\jobs-pylon\resources\views/layout/admin/jobpost.blade.php ENDPATH**/ ?>