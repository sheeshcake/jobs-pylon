<ul>
    <?php if(Route::current()->getName()): ?>
    <li><a class="nav-link scrollto active" href="/">Home</a></li>
    <?php endif; ?>
    <?php if(!auth('user')->check()): ?>
    <li><a class="nav-link scrollto" href="/login">Login</a></li>
    <?php else: ?>
    <li><a class="nav-link scrollto" href="/logout">Logout</a></li>
    <?php endif; ?>
</ul><?php /**PATH C:\Users\Pylon\Documents\LaravelWorkspace\jobs-pylon\resources\views/layout/includes/topbar.blade.php ENDPATH**/ ?>