


<?php $__env->startSection('topbar'); ?>
    <?php echo $__env->make('layout.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <ol>
          <li><a href="/">Home</a></li>
          <li>Jobs</li>
        </ol>
        <h2>Jobs</h2>

      </div>
    </section><!-- End Breadcrumbs -->
    <section id="blog" class="blog">
        <div class="container" data-aos="fade-up">

            <div class="row">

                <div class="col-lg-8 entries">
                    <?php $__currentLoopData = $data['jobposts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="entry">

                        <div class="entry-img">
                            <img src="<?php echo e(url('/')); ?>/img/jobimages/<?php echo e($jobpost['job_image']); ?>" alt="" class="img-fluid">
                        </div>

                        <h2 class="entry-title">
                            <a href="<?php echo e(route('site.jobpost', $jobpost['id'])); ?>"><?php echo e($jobpost['job_title']); ?></a>
                        </h2>

                        <div class="entry-meta">
                            <ul>
                                <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="<?php echo e(route('site.jobpost', $jobpost['id'])); ?>"><time datetime="2020-01-01"><?php echo e(\Carbon\Carbon::parse($jobpost['created_at'])->diffForHumans()); ?></time></a></li>
                            </ul>
                        </div>

                        <div class="entry-content">
                            <p>
                                <?php echo strip_tags(Str::limit($jobpost['job_description'], 300, $end='...')); ?>

                            </p>
                            <div class="read-more">
                            <a href="<?php echo e(route('site.jobpost', $jobpost['id'])); ?>">Read More</a>
                            </div>
                        </div>

                    </article><!-- End blog entry -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="my-3 d-flex justify-content-center">
                <?php echo $data['jobposts']->links("pagination::bootstrap-4"); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pylon\Documents\LaravelWorkspace\jobs-pylon\resources\views/layout/jobposts.blade.php ENDPATH**/ ?>