

<?php $__env->startSection('topbar'); ?>
    <?php echo $__env->make('layout.admin.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="my-3 d-flex justify-content-center">
            <h3>Job Posts</h3>
        </div>
        <?php if(isset($alert)): ?>
            <div class="alert alert-<?php echo e($alert['status']); ?>"><?php echo e($alert['msg']); ?></div>
        <?php endif; ?>
        <div class="container">
            <a href="<?php echo e(route('admin.createpost')); ?>" class="btn btn-primary">Create New Post</a>
            <?php $__currentLoopData = $data['posts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card my-2">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-10">
                                <?php echo e($post["job_title"]); ?>

                            </div>
                            <div class="col-2">
                                <a href="<?php echo e(route('admin.removepost', $post['id'])); ?>" class="btn border border-danger text-danger">Delete</a>
                                <a href="<?php echo e(route('admin.jobpost', $post['id'])); ?>" class="btn btn-primary">Open</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="my-3 d-flex justify-content-center">
                <?php echo $data['posts']->links("pagination::bootstrap-4"); ?>

            </div>
        </div>

    </section>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pylon\Documents\LaravelWorkspace\jobs-pylon\resources\views/layout/admin/jobposts.blade.php ENDPATH**/ ?>