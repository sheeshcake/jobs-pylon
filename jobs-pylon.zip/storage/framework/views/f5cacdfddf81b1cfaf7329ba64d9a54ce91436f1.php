

<?php $__env->startSection('hero'); ?>
    <?php echo $__env->make('layout.includes.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('topbar'); ?>
    <?php echo $__env->make('layout.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section id="jobs" class="recent-blog-posts">
        <div class="container" data-aos="fade-up">
            <header class="section-header">
                <h2>Jobs</h2>
                <p>Recent Job Posts</p>
            </header>
            <div class="row">
                <?php $__currentLoopData = $data['jobposts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4">
                    <div class="post-box">
                        <div class="post-img">
                            <img src="<?php echo e(url('/')); ?>/img/jobimages/<?php echo e($jobpost['job_image']); ?>" class="img-fluid" alt="">
                        </div>
                        <span class="post-date"><?php echo e(\Carbon\Carbon::parse($jobpost['created_at'])->diffForHumans()); ?></span>
                        <h3 class="post-title"><?php echo e($jobpost['job_title']); ?></h3>
                        <a href="<?php echo e(route('site.jobpost', $jobpost['id'])); ?>" class="readmore stretched-link mt-auto"><span>Read More</span><i class="bi bi-arrow-right"></i></a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="my-3 d-flex justify-content-center">
                <a href="<?php echo e(route('site.jobposts')); ?>" class="btn btn-primary">Show All</a>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pylon\Documents\LaravelWorkspace\jobs-pylon\resources\views/layout/main.blade.php ENDPATH**/ ?>