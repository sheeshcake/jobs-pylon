

<?php $__env->startSection('content'); ?>

<section>
    <div class="d-flex justify-content-center my-5">
        <div class="row my-5">
            <dib class="col">
                <img src="<?php echo e(url('/')); ?>/img/login.jpg" alt="" class="img-fluid">
            </dib>
            <div class="col mx-3">
                <form action="/adminlogin" method="POST">
                    <?php echo csrf_field(); ?>
                    <h3>Login as Admin</h3>
                    <?php if($errors->any()): ?>
                        <?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

                    <?php endif; ?>
                    <div class="form-group row my-3">
                        <input type="text" id="username_input" name="username" required class="form-control" placeholder="Username">
                    </div>
                    <div class="form-group row my-3">
                        <input type="password" id="password_input" name="password" required class="form-control" placeholder="Password">
                    </div>
                    <div class="row my-3">
                        <input type="submit" class="btn btn-primary" value="Login">
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pylon\Documents\LaravelWorkspace\jobs-pylon\resources\views/layout/auth/adminlogin.blade.php ENDPATH**/ ?>